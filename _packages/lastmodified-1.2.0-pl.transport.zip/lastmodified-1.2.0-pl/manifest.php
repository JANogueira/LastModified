<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for LastModified

1.2.0-pl - 2025-05-24
- Forked by João Nogueira from the original release by Kudashev Sergey
- Dual compatibility: MODX 2.x and MODX 3.x
- PHP 8.x compatibility fixes
- Fixed undefined $resource variable in OnDocFormSave (now uses $modx->event->params)
- Added $_SESSION null guard for CLI/API contexts
- Added null coalescing for $_SERVER[\'SERVER_PROTOCOL\']
- Added strtotime() return value validation
- Snippet: added file_exists() and realpath() security checks to prevent path traversal
- Snippet: added proper error logging when parameters are missing
- Added Portuguese (pt) lexicon translations
- Removed clearCache() calls that could fail on certain MODX configurations
- Minor code style improvements

1.1.1-pl - 2022-12-29
- Remove some redundant empty value checks
- Update README file
- Some improvements

1.1.0-pl - 2021-12-14
- Add exclude by id setting
- Refactor plugin code and logic
- Update README information and settings
- Update code style
- Some improvements

1.0.10-pl
- Add clear cache for all updated documents on OnDocFormSave
- Massive refactoring
- Update .gitignore

1.0.9-pl
- Add contexts support
- Some improvements

1.0.8-pl
- Add prevent on session variables names

1.0.7-pl
- Add prevent handling for authorized users
- Some improvements

1.0.6-pl
- Add update start page
- Some improvements

1.0.5-pl
- Add update nesting level

1.0.4-pl
- Parent 0 bugfix
- Some improvements

1.0.3-pl
- Add update parent editedon functionality
- Some phpdoc annotation update

1.0.2-pl
- Add response directive option
- Update lexicon files and docs
- Some improvements

1.0.1-pl
- Add maxage and expires options
- Add HTTP protocol version
- Update lexicon files and docs

1.0.0-pl
- Initial release
',
    'license' => 'MIT License

Copyright (c) 2018 Sergey Kudashev

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '--------------------
LastModified — Custom dual-compat build by João Nogueira from original release 1.1.1 by Kudashev Sergey
--------------------

This package provides dual compatibility with MODX Revolution 2.x and MODX 3.x,
along with PHP 8.x hardening and security improvements for the lastModified snippet.

Changes in this build:
- Dual-compat: works on MODX 2.x and MODX 3.x without modification
- PHP 8.x: fixed undefined variable, added null guards, proper type checks
- Security: snippet now validates file paths stay within web root
- Lexicon: added Portuguese (pt) translations
- No behavioural changes to the core caching logic

--------------------
Original README by Kudashev Sergey:
--------------------
Author: Kudashev Sergey <kudashevs@gmail.com>
--------------------

This MODx Revolution plugin handles If-Modified-Since request header and returns Last-Modified response header
with the response code 304 when it is necessary (more info and site check on https://last-modified.com/en/)

--------------------
Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/kudashevs/LastModified/issues
',
    'setup-options' => 'lastmodified-1.2.0-pl/setup-options.php',
    'requires' => 
    array (
      'php' => '>=7.4.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6bba0d802d5c4eb47252a0ab0f933507',
      'native_key' => 'lastmodified',
      'filename' => 'modNamespace/42cad0814e92938309743ea60af3d747.vehicle',
      'namespace' => 'lastmodified',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5e797916a8eb1f342bb36c009ca43f91',
      'native_key' => 1,
      'filename' => 'modCategory/ea692975ba16bd290de02a892bec9b44.vehicle',
      'namespace' => 'lastmodified',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18d56b624f4f2fa35c32e374874f5dd8',
      'native_key' => 'lastmodified.response',
      'filename' => 'modSystemSetting/c0ffb94ce8ca615c15786c27e67e6301.vehicle',
      'namespace' => 'lastmodified',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9642fcd6305adecbeead57891ba8690d',
      'native_key' => 'lastmodified.maxage',
      'filename' => 'modSystemSetting/084c82aa73f7b70cec74a79c4fd08b91.vehicle',
      'namespace' => 'lastmodified',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96a7c7d35a2414ec61ed191c7e54cd80',
      'native_key' => 'lastmodified.expires',
      'filename' => 'modSystemSetting/55528c6f4e7dcd0d3f77f8567e570973.vehicle',
      'namespace' => 'lastmodified',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afc457296044676e65ccff2d166d5c3d',
      'native_key' => 'lastmodified.update_parent',
      'filename' => 'modSystemSetting/83e0497923f2431ba94ba191cee54c12.vehicle',
      'namespace' => 'lastmodified',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93c53f6eea8f54dd3b7147d203f20486',
      'native_key' => 'lastmodified.update_level',
      'filename' => 'modSystemSetting/afb86f929f5eac09e107855a4741a0b2.vehicle',
      'namespace' => 'lastmodified',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c15740d61f20c42fb56bfea72d40fc5a',
      'native_key' => 'lastmodified.update_start',
      'filename' => 'modSystemSetting/172b205c42d9e9f829d9fc1e37b081c9.vehicle',
      'namespace' => 'lastmodified',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4603ee246d55a1918cfa3a85481db0f',
      'native_key' => 'lastmodified.prevent_authorized',
      'filename' => 'modSystemSetting/e3f19c38463815ebb887d50eae8cce4e.vehicle',
      'namespace' => 'lastmodified',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5758f307e9465007216995171db1d0aa',
      'native_key' => 'lastmodified.prevent_session',
      'filename' => 'modSystemSetting/669019b2a7fe355f10eff1ad347a1f30.vehicle',
      'namespace' => 'lastmodified',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ec84ea27ec86bc6e8a7f7407ba0702a',
      'native_key' => 'lastmodified.exclude',
      'filename' => 'modSystemSetting/b947f96a8fbe540e2480aace6d334ec4.vehicle',
      'namespace' => 'lastmodified',
    ),
  ),
);